# -*- coding: utf-8 -*-
import stock
# comentamos el import sale para desabiltar la opcion de que se complete el monto
